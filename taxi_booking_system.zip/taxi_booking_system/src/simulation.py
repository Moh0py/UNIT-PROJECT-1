import time
from asciimatics.screen import Screen
from geopy.geocoders import Nominatim


def get_coordinates(place, geolocator):
   
    location = geolocator.geocode(place)
    if not location:
        raise ValueError(f"Cannot geocode: '{place}'")
    return (location.latitude, location.longitude)


def interpolate(route_coords, steps=10):
   
    points = []
    for i in range(len(route_coords) - 1):
        lat1, lon1 = route_coords[i]
        lat2, lon2 = route_coords[i + 1]
        for s in range(steps):
            t = s / steps
            lat = lat1 + t * (lat2 - lat1)
            lon = lon1 + t * (lon2 - lon1)
            points.append((lat, lon))
    points.append(route_coords[-1])
    return points


def map_to_grid(latlon_points, width, height):
    
    lats = [pt[0] for pt in latlon_points]
    lons = [pt[1] for pt in latlon_points]
    min_lat, max_lat = min(lats), max(lats)
    min_lon, max_lon = min(lons), max(lons)
    grid = []
    for lat, lon in latlon_points:
        x = int((lon - min_lon) / (max_lon - min_lon) * (width - 2)) + 1 if max_lon != min_lon else width // 2
        y = int((lat - min_lat) / (max_lat - min_lat) * (height - 2)) + 1 if max_lat != min_lat else height // 2
        grid.append((x, y))
    return grid


def simulate_ascii_route(places, steps=10):
    """
    Simulate the taxi route on an ASCII map given a list of place names.
    """
    geolocator = Nominatim(user_agent="taxi_simulation_integration")
    # Geocode places
    route_coords = [get_coordinates(place, geolocator) for place in places]
    # Interpolate and map
    latlon_points = interpolate(route_coords, steps)

    def _draw(screen):
        grid_points = map_to_grid(latlon_points, screen.width, screen.height)
        for idx, (x, y) in enumerate(grid_points):
            screen.clear()
            # Draw border
            w, h = min(screen.width, 80), min(screen.height, 24)
            for i in range(w):
                screen.print_at('-', i, 0); screen.print_at('-', i, h-1)
            for j in range(h):
                screen.print_at('|', 0, j); screen.print_at('|', w-1, j)
            # Draw full path
            for px, py in grid_points:
                screen.print_at('.', px, py)
            # Draw current driver
            screen.print_at('D', x, y)
            screen.print_at(f"Step {idx+1}/{len(grid_points)}", 2, h-1)
            screen.refresh(); time.sleep(0.5)

    Screen.wrapper(_draw)



